# Rent-a-Car Management System

This repository contains a semester project for Object-Oriented Programming (OOP) developed in Java. It is a mini-project designed to demonstrate key principles of OOP.

 Access Credentials

- Username: admin
- Password: 123

 Important Notice

**Please note that this repository is no longer actively maintained.** Users are encouraged to utilize and modify the code at their own discretion. No further updates or support will be provided.